/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author user
 */
public class Detail extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
           String roll=request.getParameter("rolno");
           Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student_info","root","shweta");
         PreparedStatement ps=con.prepareStatement("select * from details where ROLLNO=? ");
         ps.setString(1,roll);
         ResultSet rs=ps.executeQuery();
       rs.next();
       out.println("<img align='left' src='CBSC.jpg' width='200' heigth='200'/>");
       out.println("<h1 align='center'>CBSC EXAMINATION RESULTS</h1><br/><br/>");
       out.println("<table align='center' border='1' width='300'>");
       out.println("<tr><th colspan='2'>STUDENT RESULT</th></tr> ");
       out.println("<tr><td>ROLLNO :</td><td>"+rs.getString(1)+"</td></tr>");
       out.println("<tr><td>NAME :</td><td>"+rs.getString(2)+"</td></tr>");
       out.println("<tr><td>BIRTH DATE :</td><td>"+rs.getString(3)+"</td></tr>");
       out.println("<tr><td>FATHER'S NAME :</td><td>"+rs.getString(4)+"</td></tr><br/><br/>");
       out.println("<tr><td> SUBJECTS </td><td>MARKS</td></tr>");
       out.println("<tr><td>MATHS :</td><td>"+rs.getString(5)+"</td></tr>");
       out.println("<tr><td>ENGLISH :</td><td>"+rs.getString(6)+"</td></tr>");
       out.println("<tr><td>PHYSICS :</td><td>"+rs.getString(7)+"</td></tr>");
       out.println("<tr><td>CHEMISTRY :</td><td>"+rs.getString(8)+"</td></tr>");
       out.println("<tr><td>COMPUTERS :</td><td>"+rs.getString(9)+"</td></tr>");
       out.println("</table>");
       con.close();
        }
    
        catch(ClassNotFoundException ex)
        {
            System.out.println(ex);
        }
        catch(SQLException ex)
        {
            System.out.println(ex);
                    
        }
    
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
